# aqil-icon
very lightweight icon-font
easy to use

Check Out <a href="https://md-aqil.github.io/aqil-icon/">Demo</a>


#   How to use it:



<span>
	Include the stylesheet on your document's <head>
	
</span>
	


	<head>
	  <link rel="stylesheet" href="aqil-icon/style.css">
	</head>



	Use any html tag to use icon like
	
	<i class="aqil-icon-pencil-edit-button"></i>


	
