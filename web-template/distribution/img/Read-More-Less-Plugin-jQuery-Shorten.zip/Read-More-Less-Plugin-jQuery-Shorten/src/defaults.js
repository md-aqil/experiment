export default {
  namespace: 'shorten',
  chars: 100,
  ellipses: '...',
  more: 'more',
  less: 'less'
};
